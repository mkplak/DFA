Melissa Plakyda
CSCE 355 Final Project

I did the simulator and the boolop (closure properties on complement and product construction) tasks.

I also did the inverse homomorphism task for extra credit.
